<?php
require "connection.php";

$task_method = $_REQUEST["task_method"];
$group_leader = $_REQUEST["group_leader"];
$assigned_task = $_REQUEST["assigned_task"];
$task_duration = $_REQUEST["task_duration"];
$task_date = date("d/m/Y");

if($_FILES["fileToUpload"]["name"] != ""){
$bytes = random_bytes(4);
$randName = bin2hex($bytes);

$target_dir = "mentor_uploaded_files/";
$target_file = $target_dir . $randName . "_" . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$fileuploaded = "false";

if (file_exists($target_file)) {
  //echo "Sorry, file already exists.";
  $uploadOk = 0;
}

if($uploadOk == 1){
if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
    $fileuploaded = "true";
    $mentor_file = $randName . "_" . basename($_FILES["fileToUpload"]["name"]);
    //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
  }
  else {
    //echo "Sorry, there was an error uploading your file.";
    $fileuploaded = "false";
  }
  }
  if($task_method == "update" && $fileuploaded == "true"){
    $sql = "UPDATE task_list SET assigned_task='$assigned_task', task_date='$task_date', task_duration='$task_duration', mentor_file='$mentor_file' WHERE group_leader='$group_leader'";
    }
    if($task_method == "insert" && $fileuploaded == "true"){
    $sql = "INSERT INTO task_list".
      "(group_leader, assigned_task, completed_task, task_date, task_duration, task_status, mentor_file, student_file) "."VALUES ".
      "('$group_leader','$assigned_task','','$task_date','$task_duration','Incomplete', '$mentor_file', 'No File Found!')";
    }
}
else{
    if($task_method == "update"){
    $sql = "UPDATE task_list SET assigned_task='$assigned_task', task_date='$task_date', task_duration='$task_duration' WHERE group_leader='$group_leader'";
    }
    if($task_method == "insert"){
    $sql = "INSERT INTO task_list".
      "(group_leader, assigned_task, completed_task, task_date, task_duration, task_status, mentor_file, student_file) "."VALUES ".
      "('$group_leader','$assigned_task','','$task_date','$task_duration','Incomplete', 'No File Found!', 'No File Found!')";
    }
}


// echo "<html>File : ".$mentor_file."<br>Method : ".$task_method."<br>Leader : ".$group_leader."<br>Task : ".$assigned_task."<br>Duration : ".$task_duration."<br>Date : ".$task_date."<br>fileuploaded : ".$fileuploaded."</html>";

$response = mysqli_query($conn, $sql);

if(!$response ){
    die('Could not enter data: ' . mysqli_error($conn));
    if($fileuploaded == "true"){
        unlink($target_file);
    }
}
         
echo "true";
mysqli_close($conn);
?>