<?php
$servername = "localhost";
$username = "id14931645_divya";
$password = "@Divyakenjale9834";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$conn -> select_db("id14931645_spdms");

?>