<?php
require "connection.php";

$student_email = $_REQUEST["student_email"];
$project_title = $_REQUEST["project_title"];
$project_descp = $_REQUEST["project_descp"];
$group_id = $_REQUEST["group_id"];
$member_1 = $_REQUEST["member_1"];
$member_2 = $_REQUEST["member_2"];
$member_3 = $_REQUEST["member_3"];
$member_4 = $_REQUEST["member_4"];

$sql = "SELECT * FROM project_details WHERE student_email='$student_email'";
$response = $conn->query($sql);

if ($response->num_rows > 0) {
$Sql = "UPDATE project_details SET project_title='$project_title', project_description='$project_descp', group_id='$group_id', grp_member_1='$member_1', grp_member_2='$member_2', grp_member_3='$member_3', grp_member_4='$member_4' WHERE student_email='$student_email'";
}
else{
$Sql = "INSERT INTO project_details ".
      "(student_email, project_title, project_description, group_id, grp_member_1, grp_member_2, grp_member_3, grp_member_4, mentor) "."VALUES ".
      "('$student_email','$project_title','$project_descp','$group_id','$member_1','$member_2','$member_3','$member_4','none')";
}


$Response = mysqli_query($conn, $Sql);

if(!$Response ){
    die('Could not enter data: ' . mysqli_error());
}
         
echo "true";
mysqli_close($conn);
?>