<?php
require "connection.php";

$mentor_name = $_REQUEST["mentor_name"];
$mentor_email = $_REQUEST["mentor_email"];
$mentor_mobile = $_REQUEST["mentor_mobile"];
$mentor_password = $_REQUEST["mentor_password"];
$mentor_subject = $_REQUEST["mentor_subject"];
$mentor_branch = $_REQUEST["mentor_branch"];

$sql = "INSERT INTO mentor_details ".
       "(name, email, mobile, password, subject, branch) "."VALUES ".
       "('$mentor_name','$mentor_email','$mentor_mobile','$mentor_password','$mentor_subject','$mentor_branch')";
               
$response = mysqli_query($conn, $sql);

if(!$response ){
    die('Could not enter data: ' . mysqli_error());
}
         
echo "true";
mysqli_close($conn);
?>