<?php
require "connection.php";

$group_leader = $_REQUEST["group_leader"];

$sql = "SELECT * FROM task_list WHERE group_leader='$group_leader'";

$response = $conn->query($sql);

if ($response->num_rows > 0) {
  // output data of each row
  while($row = $response->fetch_assoc()) {
    $arrInfo[] = $row;
  }
	echo json_encode(array('success'=>'true','Tasks'=>$arrInfo));
 }
$conn->close();
?>