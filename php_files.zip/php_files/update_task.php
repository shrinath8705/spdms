<?php
require "connection.php";

$completed_task = $_REQUEST["completed_task"];
$group_leader = $_REQUEST["group_leader"];
$task_id = $_REQUEST["task_id"];

if(isset($_FILES["student_file"]["name"])){
$bytes = random_bytes(4);
$randName = bin2hex($bytes);

$target_dir = "student_uploaded_files/";
$target_file = $target_dir . $randName . "_" . basename($_FILES["student_file"]["name"]);
$uploadOk = 1;
$fileuploaded = "false";

if (file_exists($target_file)) {
  //echo "Sorry, file already exists.";
  $uploadOk = 0;
}

if($uploadOk == 1){
if (move_uploaded_file($_FILES["student_file"]["tmp_name"], $target_file)) {
    $fileuploaded = "true";
    $student_file = $randName . "_" . basename($_FILES["student_file"]["name"]);
    //echo "The file ". basename( $_FILES["student_file"]["name"]). " has been uploaded.";
  }
  else {
    //echo "Sorry, there was an error uploading your file.";
    $fileuploaded = "false";
  }
  }
    $sql = "UPDATE task_list SET completed_task='$completed_task', student_file='$student_file' WHERE group_leader='$group_leader' AND id='$task_id'";
}
else{
    $sql = "UPDATE task_list SET completed_task='$completed_task' WHERE group_leader='$group_leader' AND id='$task_id'";
}
               
$response = mysqli_query($conn, $sql);

if(!$response ){
    die('Could not enter data: ' . mysqli_error($conn));
    if($fileuploaded == "true"){
        unlink($target_file);
    }
}
         
echo "true";
mysqli_close($conn);
?>