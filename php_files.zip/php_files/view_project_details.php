<?php
require "connection.php";

$student_email = $_REQUEST["student_email"];

$sql = "SELECT * FROM project_details WHERE student_email='$student_email'";

$response = $conn->query($sql);

if ($response->num_rows > 0) {
  // output data of each row
  while($row = $response->fetch_assoc()) {
    $arrInfo[] = $row;
  }
	echo json_encode(array('success'=>'true','Project'=>$arrInfo));
 }
$conn->close();
?>