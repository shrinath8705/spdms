<?php
require "connection.php";

$task_status = $_REQUEST["task_status"];
$group_leader = $_REQUEST["group_leader"];
$task_id = $_REQUEST["task_id"];

//echo $task_status ." ". $group_leader ." ". $task_id;

$sql = "UPDATE task_list SET task_status='$task_status' WHERE group_leader='$group_leader' AND id='$task_id'";
               
$response = mysqli_query($conn, $sql);

if(!$response ){
    die('Could not enter data: ' . mysqli_error());
}
         
echo "true";
mysqli_close($conn);
?>