<?php
require "connection.php";

$sql = "SELECT * FROM mentor_details";

$response = $conn->query($sql);

if ($response->num_rows > 0) {
  // output data of each row
  while($row = $response->fetch_assoc()) {
    $arrInfo[] = $row;
  }
	echo json_encode(array('success'=>'true','Mentors'=>$arrInfo));
 }
$conn->close();
?>