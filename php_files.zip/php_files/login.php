<?php
require "connection.php";

$user_tag = $_REQUEST["user_tag"];
$user_email = $_REQUEST["user_email"];
$user_password = $_REQUEST["user_password"];

$sql = "SELECT email FROM $user_tag WHERE email='$user_email' AND password='$user_password'";

$response = $conn->query($sql);

if ($response->num_rows > 0) {
  // output data of each row
  while($row = $response->fetch_assoc()) {
      echo "true";
  }
}
$conn->close();
?>