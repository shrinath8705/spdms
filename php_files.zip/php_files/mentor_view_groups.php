<?php
require "connection.php";

$mentor_email = $_REQUEST["mentor_email"];

$sql = "SELECT * FROM project_details WHERE mentor='$mentor_email'";

$response = $conn->query($sql);

if ($response->num_rows > 0) {
  // output data of each row
  while($row = $response->fetch_assoc()) {
    $arrInfo[] = $row;
  }
	echo json_encode(array('success'=>'true','Groups'=>$arrInfo));
 }
$conn->close();
?>