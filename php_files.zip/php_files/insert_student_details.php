<?php
require "connection.php";

$student_name = $_REQUEST["student_name"];
$student_email = $_REQUEST["student_email"];
$student_mobile = $_REQUEST["student_mobile"];
$student_password = $_REQUEST["student_password"];
$student_year = $_REQUEST["student_year"];
$student_branch = $_REQUEST["student_branch"];

$sql = "INSERT INTO student_details ".
       "(name, email, mobile, password, year, branch) "."VALUES ".
       "('$student_name','$student_email','$student_mobile','$student_password','$student_year','$student_branch')";
               
$response = mysqli_query($conn, $sql);

if(!$response ){
    die('Could not enter data: ' . mysqli_error());
}
         
echo "true";
mysqli_close($conn);
?>