<?php
require "connection.php";

$mentor_email = $_REQUEST["mentor_email"];
$student_email = $_REQUEST["group_leader"];

$sql = "UPDATE project_details SET mentor='$mentor_email' WHERE student_email='$student_email'";
               
$response = mysqli_query($conn, $sql);

if(!$response ){
    die('Could not enter data: ' . mysqli_error());
}
         
echo "true";
mysqli_close($conn);
?>